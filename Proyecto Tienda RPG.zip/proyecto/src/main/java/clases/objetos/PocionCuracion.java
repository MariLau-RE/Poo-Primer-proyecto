/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.objetos;

import clases.Jugador;
import clases.ObjectCollision;
import clases.Sprite;

/**
 *
 * @author Josué Alvarez M
 */
public class PocionCuracion extends Item{
    public PocionCuracion(Jugador jugador, Sprite sprite) {
        super("Poción de Curación", "pocionCuracion", 16, 0,sprite, jugador);
    }

    @Override
    public Item newInstance() {
        Item item = new PocionCuracion(jugador, (new Sprite(sprite.getImagen().getDireccion())));
        item.getSprite().setColision(sprite.getColision().newInstance());
        return item;
    }

    @Override
    public void Colision(ObjectCollision objeto) {
        colisionItem((Item) objeto);
    }

    @Override
    public void run() {
        while(true){
            verificarColision();
        }
    }
    
    @Override
    public void usar() {
        Item item = FabricaItems.newItem(ID);
        item.setCantidad(-1);
        jugador.getInventario().addItem(item);
        jugador.agregarVida(25);
    }
}
