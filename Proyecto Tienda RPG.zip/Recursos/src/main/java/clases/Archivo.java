package clases;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class Archivo {
    private final File archivo;
    
    public Archivo(String nombre){
        this.archivo = new File(nombre);
        //Creea el archivo si no existe
        if(!archivo.exists())
            crearArchivo();
    }
    
    public Archivo(String nombre, String direccion){
        this.archivo = new File(direccion + nombre);
        //Creea el archivo si no existe
        if(!archivo.exists())
            crearArchivo();
    }
    
    private void crearArchivo(){
        try {
            BufferedWriter bw;
            bw = new BufferedWriter(new FileWriter(archivo));
            bw.write("");
            bw.close();
        } catch (Exception e) {}
    }

    public File getArchivo() {
        return archivo;
    }
    
    public String getTexto(){
        String texto = ""; 
        try{
            BufferedReader br = new BufferedReader(new FileReader(this.archivo));
            try {
                String linea;
                while((linea = br.readLine()) != null)
                    texto += linea + "\n";
                return texto;
            } catch (Exception e) {}
        } catch(Exception e){}
        return null;
    }
    
    public void setTexto(String entrada){
        try{
            BufferedWriter bw = new BufferedWriter(new FileWriter(this.archivo));
            bw.write(entrada);
            bw.close();
        }catch(Exception e){}
    }
    
}