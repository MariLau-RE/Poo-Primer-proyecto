/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.objetos;

import clases.Jugador;
import clases.Sprite;
import java.util.ArrayList;

/**
 *
 * @author Josué Alvarez M
 */
public class FabricaItems {
    private static FabricaItems instance;
    private static final ArrayList<Item> items = new ArrayList();

    private FabricaItems(String dirImagenes, Jugador jugador) {
        String dir = dirImagenes + "\\objetos";
        
        FabricaItems.items.add((Item) new PocionDefensa(jugador, new Sprite(dir + "\\pociones\\pocionDefensa.png")));
        FabricaItems.items.add((Item) new PocionVeneno(jugador, new Sprite(dir + "\\pociones\\pocionVeneno.png")));
        FabricaItems.items.add((Item) new PocionCuracion(jugador, new Sprite(dir + "\\pociones\\pocionCuracion.png")));
        
        FabricaItems.items.add((Item) new EspadaHierro(jugador, new Sprite(dir + "\\espadas\\espadaHierro.png")));
        
        FabricaItems.items.add((Item) new CascoCuero(jugador, new Sprite(dir + "\\cascos\\cascoCuero.png")));
        FabricaItems.items.add((Item) new CascoHierro(jugador, new Sprite(dir + "\\cascos\\cascoHierro.png")));
        
        FabricaItems.items.add((Item) new PetoCuero(jugador, new Sprite(dir + "\\petos\\petoCuero.png")));
        FabricaItems.items.add((Item) new PetoHierro(jugador, new Sprite(dir + "\\petos\\petoHierro.png")));
        FabricaItems.items.add((Item) new PetoOro(jugador, new Sprite(dir + "\\petos\\petoOro.png")));
        
        FabricaItems.items.add((Item) new BotasCuero(jugador, new Sprite(dir + "\\botas\\botasCuero.png")));
        FabricaItems.items.add((Item) new BotasHierro(jugador, new Sprite(dir + "\\botas\\botasHierro.png")));
        FabricaItems.items.add((Item) new BotasOro(jugador, new Sprite(dir + "\\botas\\botasOro.png")));
        
        initImagenes();
    }
    
    private void initImagenes(){
        for (Item item : items) {
            item.getColision().setCirculo(true);
            item.getColision().setRadio(30);
        }
    }
    
    public static FabricaItems createInstance(String dirImagenes, Jugador jugador){
        if(FabricaItems.instance == null){
            FabricaItems.instance = new FabricaItems(dirImagenes, jugador);
            return FabricaItems.instance;
        }
        return null;
    }
    
    public static Item newItem(String ID){
        for (Item objeto : items) {
            if(objeto.getID().equals(ID)){
                return objeto.newInstance();
            }
        }
        return null;
    }
}
