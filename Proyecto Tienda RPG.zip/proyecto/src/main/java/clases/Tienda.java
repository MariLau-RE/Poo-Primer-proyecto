/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.FabricaItems;
import clases.objetos.Item;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;

/**
 *
 * @author Josué Alvarez M
 */
public class Tienda extends Thread implements ActionListener{
    private final Ventana ventana;
    private final Jugador jugador;
    private final String dirImagenes;
    private final ArrayList<Articulo> articulos = new ArrayList();
    private final ArrayList<Articulo> invJugador = new ArrayList();
    private final JLayeredPane panelTienda;
    private final JLabel labelTienda;
    private final JButton botonTienda;
    private final JButton btnAumentarT;
    private final JButton btnDisminuirT;
    private final JButton btnAumentarJ;
    private final JButton btnDisminuirJ;
    private Articulo articuloSelecionado;
    private boolean mostrar;
    private int paginaT;
    private int paginaJ;
    
    public Tienda(String dirImagenes, Ventana ventana, Jugador jugador) {
        this.ventana = ventana;
        this.jugador = jugador;
        this.dirImagenes = dirImagenes;
        
        this.panelTienda = new JLayeredPane();
        this.panelTienda.setVisible(false);
        
        this.labelTienda = new JLabel((new Imagen(dirImagenes + "\\gui\\tienda.png")).getImagen());
        
        this.botonTienda = new JButton((new Imagen(dirImagenes + "\\gui\\btnTienda1.png")).getImagen());
        this.botonTienda.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnTienda2.png")).getImagen());
        
        this.btnAumentarT = new JButton((new Imagen(dirImagenes + "\\gui\\btnAumentar1.png")).getImagen());
        this.btnAumentarT.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnAumentar2.png")).getImagen());
        
        this.btnDisminuirT = new JButton((new Imagen(dirImagenes + "\\gui\\btnDisminuir1.png")).getImagen());
        this.btnDisminuirT.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnDisminuir2.png")).getImagen());
        
        this.btnAumentarJ = new JButton((new Imagen(dirImagenes + "\\gui\\btnAumentar1.png")).getImagen());
        this.btnAumentarJ.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnAumentar2.png")).getImagen());
        
        this.btnDisminuirJ = new JButton((new Imagen(dirImagenes + "\\gui\\btnDisminuir1.png")).getImagen());
        this.btnDisminuirJ.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnDisminuir2.png")).getImagen());
        
        // articulos comprables en la tienda
        PruebaAPI p = new PruebaAPI();
        
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("pocionDefensa"), p.getPrecios(0) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("pocionVeneno"), p.getPrecios(1) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("pocionCuracion"), p.getPrecios(2) * 100));
        
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("espadaHierro"), p.getPrecios(3) * 100));
        
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("cascoCuero"), p.getPrecios(4) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("cascoHierro"), p.getPrecios(5) * 100));
        
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("petoCuero"), p.getPrecios(6) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("petoHierro"), p.getPrecios(7) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("petoOro"), p.getPrecios(8) * 100));
        
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("botasCuero"), p.getPrecios(9) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("botasHierro"), p.getPrecios(10) * 100));
        this.articulos.add(new Articulo(dirImagenes, FabricaItems.newItem("botasOro"), p.getPrecios(11) * 100));
        
        iniciarTienda();
        cargarArticulos();
        mostrarArticulos();
    }
    
    private void cargarInventario(){
        for (Articulo articulo : invJugador) {
            labelTienda.remove(articulo.getBoton());
        }
        invJugador.clear();
        
        for (Casilla casilla : jugador.getInventario().getCasillas()) {
            if(casilla.getItem() != null){
                invJugador.add(new Articulo(dirImagenes, FabricaItems.newItem(casilla.getItem().getID()), 500, true));
            }
        }
        
        int cont = 0;
        for (Articulo articulo : invJugador) {
            if(cont == 4)
                cont = 0;
            articulo.getBoton().setVisible(false);
            articulo.getBoton().setLocation(460, 190 + (10*cont) + (articulo.getBoton().getHeight()*cont));
            labelTienda.add(articulo.getBoton());
            cont ++;
        }
    }
    
    private void mostrarInventario(){
        int cont = 0; // artículo por artículo
        int cont2 = 0; // cada 4 artículos
        int cont3 = 1;
        
        for (Articulo articulo : invJugador) {
            if(cont == 4){
                cont = 0;
                cont2 ++;
            }
            
            if(paginaJ == cont2){
                cont3 = 0;
                articulo.getBoton().setVisible(true);
            }
            else
                articulo.getBoton().setVisible(false);
            cont ++;
        }
        if(cont3 == 1 && paginaJ > 0){
            paginaJ --;
            mostrarInventario();
        }
    }
    
    private void mostrarArticulos(){
        int cont = 0; // artículo por artículo
        int cont2 = 0; // cada 4 artículos
        int cont3 = 1;
        
        for (Articulo articulo : articulos) {
            if(cont == 4){
                cont = 0;
                cont2 ++;
            }
            if(paginaT == cont2){
                cont3 = 0;
                articulo.getBoton().setVisible(true);
            }
            else
                articulo.getBoton().setVisible(false);
            cont ++;
        }
        if(cont3 == 1){
            paginaT --;
            mostrarArticulos();
        }
    }
    
    private void cargarArticulos(){
        int cont = 0;
        for (Articulo articulo : articulos) {
            if(cont == 4)
                cont = 0;
            articulo.getBoton().setVisible(false);
            articulo.getBoton().setLocation(50, 190 + (10*cont) + (articulo.getBoton().getHeight()*cont));
            labelTienda.add(articulo.getBoton());
            cont ++;
        }
    }
    
    private void iniciarTienda(){
        panelTienda.setSize(1250, 750);
        panelTienda.setLocation(300, 25);
        
        labelTienda.setSize(panelTienda.getSize());
        
        // BOTONES DE AUMENTAR Y DISMINUIR
        // pagina articulos de la tienda
        btnAumentarT.setSize(btnAumentarT.getIcon().getIconWidth(), btnAumentarT.getIcon().getIconHeight());
        btnAumentarT.setLocation(300, 110);
        
        btnAumentarT.setLayout(new GridBagLayout());
        btnAumentarT.setFocusable(false);
        btnAumentarT.setOpaque(false);
        btnAumentarT.setContentAreaFilled(false);
        btnAumentarT.setBorderPainted(false);
        
        btnAumentarT.addActionListener(this);
        
        btnDisminuirT.setSize(btnDisminuirT.getIcon().getIconWidth(), btnDisminuirT.getIcon().getIconHeight());
        btnDisminuirT.setLocation(210, 110);
        
        btnDisminuirT.setLayout(new GridBagLayout());
        btnDisminuirT.setFocusable(false);
        btnDisminuirT.setOpaque(false);
        btnDisminuirT.setContentAreaFilled(false);
        btnDisminuirT.setBorderPainted(false);
        
        btnDisminuirT.addActionListener(this);
        
        //pagina articulos en el inventario del jugador
        btnAumentarJ.setSize(btnAumentarJ.getIcon().getIconWidth(), btnAumentarJ.getIcon().getIconHeight());
        btnAumentarJ.setLocation(660, 110);
        
        btnAumentarJ.setLayout(new GridBagLayout());
        btnAumentarJ.setFocusable(false);
        btnAumentarJ.setOpaque(false);
        btnAumentarJ.setContentAreaFilled(false);
        btnAumentarJ.setBorderPainted(false);
        
        btnAumentarJ.addActionListener(this);
        
        btnDisminuirJ.setSize(btnDisminuirJ.getIcon().getIconWidth(), btnDisminuirJ.getIcon().getIconHeight());
        btnDisminuirJ.setLocation(570, 110);
        
        btnDisminuirJ.setLayout(new GridBagLayout());
        btnDisminuirJ.setFocusable(false);
        btnDisminuirJ.setOpaque(false);
        btnDisminuirJ.setContentAreaFilled(false);
        btnDisminuirJ.setBorderPainted(false);
        
        btnDisminuirJ.addActionListener(this);
        
        botonTienda.setSize(botonTienda.getIcon().getIconWidth(), botonTienda.getIcon().getIconHeight());
        botonTienda.setLocation(135, 845);
        
        botonTienda.setLayout(new GridBagLayout());
        botonTienda.setFocusable(false);
        botonTienda.setOpaque(false);
        botonTienda.setContentAreaFilled(false);
        botonTienda.setBorderPainted(false);
        
        botonTienda.addActionListener(this);
        
        JLabel titulo = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>Tienda</b></p></body></html>");
        titulo.setFont(new Font("titulo", 0, 35));
        titulo.setSize(110, 50);
        titulo.setLocation(175, 40);
        
        JLabel texto = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>Inventario</b></p></body></html>");
        texto.setFont(new Font("texto", 0, 35));
        texto.setSize(165, 50);
        texto.setLocation(565, 40);
        
        labelTienda.add(btnAumentarJ);
        labelTienda.add(btnDisminuirJ);
        labelTienda.add(btnAumentarT);
        labelTienda.add(btnDisminuirT);
        labelTienda.add(texto);
        labelTienda.add(titulo);
        panelTienda.add(labelTienda);
        ventana.panelPrincipal.add(botonTienda);
        ventana.panelPrincipal.add(panelTienda, JLayeredPane.DRAG_LAYER);
        
        start();
    }
    
    public void mostrarTienda(){
        if(mostrar){
            panelTienda.setVisible(false);
            mostrar = false;
        }
        else{
            panelTienda.setVisible(true);
            mostrar = true;
        }
    }
    
    private void borrarArtSelecionado(){
        if(articuloSelecionado != null){
            labelTienda.remove(labelTienda.getComponentAt(900, 100));
            
            articuloSelecionado.getBoton().removeActionListener(this);
            articuloSelecionado.getBoton().removeAll();
            articuloSelecionado.getBoton().add(articuloSelecionado.getItem().getSprite().getLabel());
            JLabel texto = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>" + articuloSelecionado.getItem().getNombre() + ": " + 
                                                articuloSelecionado.getPrecio() + "</b></p></body></html>");
            texto.setFont(new Font("texto", 0, 15));
            articuloSelecionado.getBoton().add(texto);
            
            articuloSelecionado = null;
        }
    }
    
    @Override
    public void run(){
        while(true){
            try {
                for (Articulo articulo : articulos) {
                    if(articulo.isActivado()){
                        articulo.setActivado(false);

                        borrarArtSelecionado();

                        articulo.getBoton().removeAll();
                        articulo.getBoton().add(articulo.getItem().getSprite().getLabel());
                        JLabel texto = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>" + articulo.getItem().getNombre() + ": " + 
                                                            articulo.getPrecio() + "  ¿Comprar?</b></p></body></html>");
                        texto.setFont(new Font("texto", 0, 15));
                        articulo.getBoton().add(texto);

                        JLabel estadisticas = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>Estadisticas</b> <br><br><br> "
                                        + "Vida Máxima: " + jugador.getVidaMax() +" -> " + (jugador.getVidaMax() + articulo.getItem().getVidaMax()) 
                                        + "<br><br>Ataque: " + jugador.getAtaque() + " -> " + (jugador.getAtaque() + articulo.getItem().getAtaque()) + "<br><br>"
                                        + "Defensa: " + jugador.getDefensaMax() + " -> " + (jugador.getDefensaMax() + articulo.getItem().getDefensaMax())
                                        + "<br><br>Ataque Mágico: " + jugador.getAtaqueM() + " -> " + (jugador.getAtaqueM() + articulo.getItem().getAtaqueM()) + "<br><br>" 
                                        + "Defensa Mágica: " + jugador.getDefensaM() + " -> " + (jugador.getDefensaM()+ articulo.getItem().getDefensaM())
                                        + "<br><br>Velocidad: " + jugador.getVelocidad() + " -> " + (jugador.getVelocidad()+ articulo.getItem().getVelocidad())
                                        + "</p></body></html>");
                        estadisticas.setFont(new Font("estadisticas", 0, 25));
                        estadisticas.setLocation(900, 100);
                        estadisticas.setSize(325, 450);
                        labelTienda.add(estadisticas);

                        articuloSelecionado = articulo;
                        articuloSelecionado.getBoton().addActionListener(this);
                    }
                }

                for (Articulo articulo : invJugador) {
                    if(articulo.isActivado()){
                        articulo.setActivado(false);

                        borrarArtSelecionado();

                        articulo.getBoton().removeAll();
                        articulo.getBoton().add(articulo.getItem().getSprite().getLabel());

                        JLabel texto2 = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>" + articulo.getItem().getNombre() + ": " + 
                                                            articulo.getPrecio() + "  ¿Vender?</b></p></body></html>");
                        texto2.setFont(new Font("texto", 0, 15));
                        articulo.getBoton().add(texto2);

                        JLabel estadisticas = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>Estadisticas</b> <br><br><br> "
                                        + "Vida Máxima: " + jugador.getVidaMax() +" -> " + (jugador.getVidaMax() + articulo.getItem().getVidaMax()) 
                                        + "<br><br>Ataque: " + jugador.getAtaque() + " -> " + (jugador.getAtaque() + articulo.getItem().getAtaque()) + "<br><br>"
                                        + "Defensa: " + jugador.getDefensaMax() + " -> " + (jugador.getDefensaMax() + articulo.getItem().getDefensaMax())
                                        + "<br><br>Ataque Mágico: " + jugador.getAtaqueM() + " -> " + (jugador.getAtaqueM() + articulo.getItem().getAtaqueM()) + "<br><br>" 
                                        + "Defensa Mágica: " + jugador.getDefensaM() + " -> " + (jugador.getDefensaM()+ articulo.getItem().getDefensaM())
                                        + "<br><br>Velocidad: " + jugador.getVelocidad() + " -> " + (jugador.getVelocidad()+ articulo.getItem().getVelocidad())
                                        + "</p></body></html>");
                        estadisticas.setFont(new Font("estadisticas", 0, 25));
                        estadisticas.setLocation(900, 100);
                        estadisticas.setSize(325, 450);
                        labelTienda.add(estadisticas);

                        articuloSelecionado = articulo;
                        articuloSelecionado.getBoton().addActionListener(this);
                    }
                }
            }
            catch(Exception e){}
        }
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(botonTienda == e.getSource()){
            borrarArtSelecionado();
            
            mostrarTienda();
            
            cargarInventario();
            mostrarInventario();
        }

        if(btnAumentarT == e.getSource()){
            paginaT ++;
            mostrarArticulos();
        }
        if(btnDisminuirT == e.getSource() && paginaT > 0){
            paginaT --;
            mostrarArticulos();
        }
        if(btnAumentarJ == e.getSource()){
            paginaJ ++;
            mostrarInventario();
        }
        if(btnDisminuirJ == e.getSource() && paginaJ > 0){
            paginaJ --;
            mostrarInventario();
        }
        
        if(articuloSelecionado != null){
            if(articuloSelecionado.getBoton() == e.getSource()){
                if(articuloSelecionado.isEnJugador()){
                    jugador.agregarDinero(articuloSelecionado.getPrecio());
                    articuloSelecionado.getItem().setCantidad(-1);
                    jugador.getInventario().addItem(articuloSelecionado.getItem());
                    cargarInventario();
                    mostrarInventario();
                }
                else if(jugador.getDinero() >= articuloSelecionado.getPrecio()){
                    jugador.agregarDinero(-articuloSelecionado.getPrecio());
                    Item obj = FabricaItems.newItem(articuloSelecionado.getItem().getID());
                    obj.setCantidad(1);
                    int cantidadSobrante = jugador.getInventario().addItem(obj);
                    if(cantidadSobrante != 0)
                        jugador.agregarDinero(articuloSelecionado.getPrecio());
                }
            }
        }
    }
}
