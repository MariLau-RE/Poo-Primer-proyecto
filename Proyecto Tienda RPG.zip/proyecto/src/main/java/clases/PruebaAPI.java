package clases;

import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Response;
import com.squareup.okhttp.Request;
import java.io.IOException;
import java.util.ArrayList;
import org.json.JSONObject;



/**
 *
 * @author maril
 */
public class PruebaAPI {
    private final OkHttpClient client = new OkHttpClient();
    private final Request request;
    private final ArrayList<Integer> precios = new ArrayList();
    
    public PruebaAPI() {
        this.request = new Request.Builder()
            .url("https://ali-express1.p.rapidapi.com/shipping/4000479928418?count=1&destination_country=CO")
            .get()
            .addHeader("x-rapidapi-host", "ali-express1.p.rapidapi.com")
            .addHeader("x-rapidapi-key", "fe7fc0f01dmshd2de5cca415bf28p197895jsnd3ccc6b88c43")
            .build();
        
        iniciarPrecios();
    }
    
    public void iniciarPrecios(){
        try {
            JSONObject json;
            int num;
            for (int i = 1; i < 6; i++) {
                json = new JSONObject(getResponse().body().string());
                num = ((Integer) json.get("cost")) * i;
                precios.add(num);
                precios.add(num * (1 + i));
                precios.add(num + (num/2));
            }
        }
        catch(Exception e){}
    }
    
    public Response getResponse()throws IOException{
        Response response = client.newCall(request).execute();
        return response; 
    }

    public ArrayList<Integer> getPrecios() {
        return precios;
    }
    
    public int getPrecios(int pos) {
        return precios.get(pos);
    }
}
