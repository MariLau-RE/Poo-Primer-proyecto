/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.Item;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author Josué Alvarez M
 */
public class Articulo implements MouseListener{
    private final Item item;
    private final int precio;
    private final JButton boton;
    private final JLabel texto;
    private final boolean enJugador;
    private boolean activado; // indica true cuando el objeto si se va a comprar o vender

    public Articulo(String dirImagenes, Item item, int precio) {
        this.item = item;
        this.precio = precio;
        
        this.boton = new JButton((new Imagen(dirImagenes + "\\gui\\btnArticulo1.png")).getImagen());
        this.boton.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnArticulo2.png")).getImagen());
        
        this.texto = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>" + item.getNombre() + ": " + precio + "</b></p></body></html>");
        
        this.enJugador = false;
        
        iniciarBoton();
    }
    
    public Articulo(String dirImagenes, Item item, int precio, boolean enJugador) {
        this.item = item;
        this.precio = precio;
        
        this.boton = new JButton((new Imagen(dirImagenes + "\\gui\\btnArticulo1.png")).getImagen());
        this.boton.setPressedIcon((new Imagen(dirImagenes + "\\gui\\btnArticulo2.png")).getImagen());
        
        this.texto = new JLabel("<html><body><p style=\"color:#F2f2f2\";><b>" + item.getNombre() + ": " + precio + "</b></p></body></html>");
        
        this.enJugador = enJugador;
        
        iniciarBoton();
    }
    
    private void iniciarBoton(){
        boton.setSize(boton.getIcon().getIconWidth(), boton.getIcon().getIconHeight());
        
        boton.setLayout(new GridBagLayout());
        boton.setFocusable(false);
        boton.setOpaque(false);
        boton.setContentAreaFilled(false);
        boton.setBorderPainted(false);
        
        texto.setFont(new Font("texto", 0, 15));
        
        boton.add(item.getSprite().getLabel());
        boton.add(texto);
        
        boton.addMouseListener(this);
    }

    public Item getItem() {
        return item;
    }

    public int getPrecio() {
        return precio;
    }

    public JButton getBoton() {
        return boton;
    }

    public JLabel getTexto() {
        return texto;
    }
    
    public boolean isActivado() {
        return activado;
    }

    public boolean isEnJugador() {
        return enJugador;
    }
    
    public void setActivado(boolean activado) {
        this.activado = activado;
    }
    
    @Override
    public void mouseClicked(MouseEvent e) {}

    @Override
    public void mousePressed(MouseEvent e) {
        item.getSprite().getLabel().setLocation(item.getSprite().getLabel().getX(), item.getSprite().getLabel().getY() + 10);
        texto.setLocation(texto.getX(), texto.getY() + 10);
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        item.getSprite().getLabel().setLocation(item.getSprite().getLabel().getX(), item.getSprite().getLabel().getY() - 10);
        texto.setLocation(texto.getX(), texto.getY() - 10);
        
        activado = true;
    }

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}
}
