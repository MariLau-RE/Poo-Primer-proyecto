/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases.objetos;

import clases.Jugador;
import clases.ObjectCollision;
import clases.Sprite;

/**
 *
 * @author Josué Alvarez M
 */
public abstract class Item extends ObjectCollision{
    protected String nombre, ID;
    protected int cantidad = 1;
    protected int cantidadMax;
    protected int tipo = 0;
    protected Jugador jugador; //quien poee en objeto
    
    protected boolean equipado = false;
    protected int vidaMax;
    protected int ataque;
    protected int defensaMax;
    protected int ataqueM;
    protected int defensaM;
    protected int velocidad;
    
    public Item(String nombre, String ID, Sprite sprite) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        
        this.cantidadMax = 64;
    }

    public Item(String nombre, String ID, int cantidadMax, Sprite sprite) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        this.cantidadMax = cantidadMax;
        this.sprite.getColision().setCirculo(true);
    }
    
    public Item(String nombre, String ID, int cantidadMax, int tipo, Sprite sprite) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        this.cantidadMax = cantidadMax;
        this.sprite.getColision().setCirculo(true);
        
        this.tipo = tipo;
    }
    
    public Item(String nombre, String ID, Sprite sprite, Jugador jugador) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        this.cantidadMax = 64;
        
        this.jugador = jugador;
    }

    public Item(String nombre, String ID, int cantidadMax, Sprite sprite, Jugador jugador) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        this.cantidadMax = cantidadMax;
        this.sprite.getColision().setCirculo(true);
        
        this.jugador = jugador;
    }
    
    public Item(String nombre, String ID, int cantidadMax, int tipo, Sprite sprite, Jugador jugador) {
        super(ID, sprite);
        this.nombre = nombre;
        this.ID = ID;
        this.cantidadMax = cantidadMax;
        this.sprite.getColision().setCirculo(true);
        this.tipo = tipo;
        
        this.jugador = jugador;
    }
    
    protected void colisionItem(Item item){
        if(ID == item.getID()){
            cantidad += item.getCantidad();
            item.getColision().setActivada(false);
            jugador.getInventario().getVentana().panelPrincipal.remove(item.getSprite().getLabel());
            item.getSprite().getColision().removeCollisionController(this);
        }
    }
    
    public abstract void usar();
    
    public abstract Item newInstance();

    public boolean isEquipado() {
        return equipado;
    }

    public int getVidaMax() {
        return vidaMax;
    }

    public int getAtaque() {
        return ataque;
    }

    public int getDefensaMax() {
        return defensaMax;
    }

    public int getAtaqueM() {
        return ataqueM;
    }

    public int getDefensaM() {
        return defensaM;
    }

    public int getVelocidad() {
        return velocidad;
    }
    
    public String getNombre() {
        return nombre;
    }

    public String getID() {
        return ID;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getCantidadMax() {
        return cantidadMax;
    }

    public int getTipo() {
        return tipo;
    }

    public Jugador getJugador() {
        return jugador;
    }

    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }
    
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public void setCantidadMax(int cantidadMax) {
        this.cantidadMax = cantidadMax;
    }

    public void setEquipado(boolean equipado) {
        this.equipado = equipado;
    }

    public void setVidaMax(int vidaMax) {
        this.vidaMax = vidaMax;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }

    public void setDefensaMax(int defensaMax) {
        this.defensaMax = defensaMax;
    }

    public void setAtaqueM(int ataqueM) {
        this.ataqueM = ataqueM;
    }

    public void setDefensaM(int defensaM) {
        this.defensaM = defensaM;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }
    
    public int agregarCantidad(int cantidad){
        int cantidadSobrante = 0;
        if(cantidad > 0){
            this.cantidad += cantidad;
            if(this.cantidad > this.cantidadMax){
                cantidadSobrante = this.cantidad - this.cantidadMax;
                this.cantidad = this.cantidadMax;
            }
                
        }
        else{
            this.cantidad += cantidad;
            if(this.cantidad < 0){
                cantidadSobrante = -1*this.cantidad;
                this.cantidad = 0;
            }
        }
        
        return cantidadSobrante;
    }

    @Override
    public abstract void Colision(ObjectCollision objeto);

    @Override
    public abstract void run();
    
    
    
}
