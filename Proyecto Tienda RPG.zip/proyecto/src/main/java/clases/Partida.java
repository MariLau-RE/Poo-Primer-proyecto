/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.FabricaItems;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;

/**
 *
 * @author Josué Alvarez M
 */
public class Partida extends Thread implements KeyListener{
    private final Ventana ventana;
    private final Jugador jugador;
    private final String dirImagenes = (new Archivo("imagenes.txt")).getArchivo().getAbsolutePath().
            substring(0, (new Archivo("imagenes.txt")).getArchivo().getAbsolutePath().length() - 4);
    private final FabricaItems fabricaItems;
    private final Tienda tienda;
    private final JLabel guiJugador;
    private final JLabel guiVida;
    private final JLabel guiDefensa;
    private final JLabel guiDinero;
    
    public Partida() {
        this.ventana = new Ventana();
        this.ventana.addKeyListener(this);
        
        this.jugador = new Jugador(dirImagenes, ventana, new Cursor(ventana));
        
        this.fabricaItems = FabricaItems.createInstance(dirImagenes, jugador);
        
        this.tienda = new Tienda(dirImagenes, ventana, jugador);
        
        this.guiJugador = new JLabel((new Imagen(dirImagenes + "\\gui\\guiJugador.png")).getImagen());
        this.guiVida = new JLabel((new Imagen(dirImagenes + "\\gui\\vida.png")).getImagen());
        this.guiDefensa = new JLabel((new Imagen(dirImagenes + "\\gui\\defensa.png")).getImagen());
        this.guiDinero = new JLabel(String.valueOf(jugador.getDinero()));
        
        this.ventana.panelPrincipal.add(this.jugador.getSprite().getLabel());
        this.jugador.getSprite().setPosicion(100, 100);
        
        jugador.start();
        iniciarInfJugador();
        
        this.ventana.setVisible(true);
    }
    
    private void iniciarInfJugador(){
        guiJugador.setSize(guiJugador.getIcon().getIconWidth(), guiJugador.getIcon().getIconHeight());
        guiJugador.setLocation(10, 10);
        
        JLabel label = new JLabel((new Imagen(dirImagenes + "\\jugador\\caballeroQuietoD1.png")).getImagen());
        label.setSize(label.getIcon().getIconWidth(), label.getIcon().getIconHeight());
        label.setLocation(30, -10);
        
        guiVida.setSize(guiVida.getIcon().getIconWidth(), guiVida.getIcon().getIconHeight());
        guiVida.setLocation(130, 10);
        
        guiDefensa.setSize(guiDefensa.getIcon().getIconWidth(), guiDefensa.getIcon().getIconHeight());
        guiDefensa.setLocation(130, 40);
        
        guiDinero.setSize(200, 20);
        guiDinero.setForeground(Color.WHITE);
        guiDinero.setFont(new Font("dinero", 0, 15));
        guiDinero.setLocation(170, 80);
        
        guiJugador.add(label);
        guiJugador.add(guiVida);
        guiJugador.add(guiDefensa);
        guiJugador.add(guiDinero);
        ventana.panelPrincipal.add(guiJugador, JLayeredPane.POPUP_LAYER);
    }
    
    private void actualizarInfJugador(){
        guiDinero.setText(String.valueOf(jugador.getDinero()));
        
        double num1 = (double) jugador.getVida();
        double num2 = (double) jugador.getVidaMax();
        double num3 = num1 / num2;
        double porcentaje = guiVida.getIcon().getIconWidth() * num3;
        guiVida.setSize((int) porcentaje, guiVida.getIcon().getIconHeight());
        
        num1 = (double) jugador.getDefensa();
        num2 = (double) jugador.getDefensaMax();
        num3 = num1 / num2;
        porcentaje = guiDefensa.getIcon().getIconWidth() * num3;
        guiDefensa.setSize((int) porcentaje, guiDefensa.getIcon().getIconHeight());
    }
    
    @Override
    public void run(){
        while(true){
            try {
                actualizarInfJugador();
                ventana.panelPrincipal.repaint();
            }
            catch(Exception e){}
        }
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    @Override
    public void keyPressed(KeyEvent e) {
        int tecla = e.getKeyCode();
        
        switch (tecla) {
            case KeyEvent.VK_1:
                jugador.getInventario().setPosSeleccion(0);
                break;
            case KeyEvent.VK_2:
                jugador.getInventario().setPosSeleccion(1);
                break;
            case KeyEvent.VK_3:
                jugador.getInventario().setPosSeleccion(2);
                break;
            case KeyEvent.VK_4:
                jugador.getInventario().setPosSeleccion(3);
                break;
            case KeyEvent.VK_5:
                jugador.getInventario().setPosSeleccion(4);
                break;
            case KeyEvent.VK_6:
                jugador.getInventario().setPosSeleccion(5);
                break;
            case KeyEvent.VK_7:
                jugador.getInventario().setPosSeleccion(6);
                break;
            case KeyEvent.VK_8:
                jugador.getInventario().setPosSeleccion(7);
                break;
            case KeyEvent.VK_9:
                jugador.getInventario().setPosSeleccion(8);
                break;
            case KeyEvent.VK_W:
                jugador.arriba = true;
                break;
            case KeyEvent.VK_S:
                jugador.abajo = true;
                break;
            case KeyEvent.VK_A:
                jugador.izquierda = true;
                break;
            case KeyEvent.VK_D:
                jugador.derecha = true;
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        int tecla = e.getKeyCode();
        switch (tecla) {
            case KeyEvent.VK_Q:
                jugador.getInventario().tirarItemSeleccionado();
                break;
            case KeyEvent.VK_F:
                jugador.getInventario().usarItemSeleccionado();
                break;
            case KeyEvent.VK_G:
                if(jugador.getInventario().isMostrar())
                    jugador.getInventario().mostrarInventario();
                jugador.mostrarEstadisticas();
                break;
            case KeyEvent.VK_E:
                if(!jugador.isMostrar())
                    jugador.getInventario().mostrarInventario();
                break;
            case KeyEvent.VK_W:
                jugador.arriba = false;
                break;
            case KeyEvent.VK_S:
                jugador.abajo = false;
                break;
            case KeyEvent.VK_A:
                jugador.izquierda = false;
                break;
            case KeyEvent.VK_D:
                jugador.derecha = false;
                break;
            default:
                break;
        }
    }
}
