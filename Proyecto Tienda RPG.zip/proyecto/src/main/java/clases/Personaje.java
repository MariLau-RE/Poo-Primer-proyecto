/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

/**
 *
 * @author Josué Alvarez M
 */
public abstract class Personaje extends ObjectCollision{
    protected int vida = 100;
    protected int vidaMax = 100;
    protected int ataque = 20;
    protected int defensa = 50;
    protected int defensaMax = 50;
    protected int ataqueM = 10;
    protected int defensaM = 25;
    protected int velocidad = 10;
    
    // las estadisticas adicionales que proporciona el equipamento
    protected int vidaEq;
    protected int vidaMaxEq;
    protected int ataqueEq;
    protected int defensaMaxEq;
    protected int ataqueMEq;
    protected int defensaMEq;
    protected int velocidadEq;
    
    public Personaje(String ID, Sprite sprite) {
        super(ID, sprite);
    }
    
    public int getVida() {
        return vida + vidaEq;
    }

    public int getVidaMax() {
        return vidaMax + vidaMaxEq;
    }

    public int getAtaque() {
        return ataque + ataqueEq;
    }

    public int getDefensa() {
        return defensa;
    }
    
    public int getDefensaMax() {
        return defensaMax + defensaMaxEq;
    }
    
    public int getAtaqueM() {
        return ataqueM + ataqueMEq;
    }

    public int getDefensaM() {
        return defensaM + defensaMEq;
    }

    public int getVelocidad() {
        return velocidad + velocidadEq;
    }

    public int getVidaEq() {
        return vidaEq;
    }

    public int getVidaMaxEq() {
        return vidaMaxEq;
    }

    public int getAtaqueEq() {
        return ataqueEq;
    }

    public int getDefensaMaxEq() {
        return defensaMaxEq;
    }

    public int getAtaqueMEq() {
        return ataqueMEq;
    }

    public int getDefensaMEq() {
        return defensaMEq;
    }

    public int getVelocidadEq() {
        return velocidadEq;
    }

    public void setVidaMax(int vidaMax) {
        this.vidaMax = vidaMax;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }
    
    public void setDefensa(int defensa) {
        this.defensa = defensa;
    }
    
    public void setDefensaMax(int defensaMax) {
        this.defensaMax = defensaMax;
    }

    public void setAtaqueM(int ataqueM) {
        this.ataqueM = ataqueM;
    }

    public void setDefensaM(int defensaM) {
        this.defensaM = defensaM;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public void setVidaEq(int vidaEq) {
        this.vidaEq = vidaEq;
    }

    public void setVidaMaxEq(int vidaMaxEq) {
        this.vidaMaxEq = vidaMaxEq;
    }

    public void setAtaqueEq(int ataqueEq) {
        this.ataqueEq = ataqueEq;
    }

    public void setDefensaMaxEq(int defensaEq) {
        this.defensaMaxEq = defensaEq;
    }

    public void setAtaqueMEq(int ataqueMEq) {
        this.ataqueMEq = ataqueMEq;
    }

    public void setDefensaMEq(int defensaMEq) {
        this.defensaMEq = defensaMEq;
    }

    public void setVelocidadEq(int velocidadEq) {
        this.velocidadEq = velocidadEq;
    }
    
    public void agregarVida(int vida){
        this.vida += vida;
        if(this.vida < 0)
            this.vida = 0;
        if(this.vida > vidaMax + vidaMaxEq)
            this.vida = vidaMax + vidaMaxEq;
    }
    
    public void agregarDefensa(int defensa){
        this.defensa += defensa;
        if(this.defensa < 0)
            this.defensa = 0;
        if(this.defensa > defensaMax + defensaMaxEq)
            this.defensa = defensaMax + defensaMaxEq;
    }
    
    @Override
    public abstract void Colision(ObjectCollision objeto);

    @Override
    public abstract void run();
    
}
