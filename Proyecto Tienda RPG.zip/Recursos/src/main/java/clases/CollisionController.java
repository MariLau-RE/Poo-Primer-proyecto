/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

public class CollisionController{
    private final ObjectCollision objeto;
    private final ObjectCollision objeto2;
    private final Colision colision1;
    private final Colision colision2;
    private boolean activado = true;

    public CollisionController(ObjectCollision objeto, ObjectCollision objeto2, Colision colision1, Colision colision2) {
        this.objeto = objeto;
        this.objeto2 = objeto2;
        this.colision1 = colision1;
        this.colision2 = colision2;
    }
    
    public void verificarColision(){
        if(colision1.isActivada() && colision2.isActivada()){

            int x1 = colision1.getPosX();
            int y1 = colision1.getPosY();
            int x2 = colision2.getPosX();
            int y2 = colision2.getPosY();

            int r1;
            int r2;
            int cont = 0; // cont == 1, ocurió una colision
            if(this.colision1.isCirculo() && this.colision2.isCirculo()){ // circulo - circulo
                x1 += colision1.getCentroX();
                y1 += colision1.getCentroY();

                x2 += colision2.getCentroX();
                y2 += colision2.getCentroY();

                r1 = colision1.getRadio();
                r2 = colision2.getRadio();

                if(Math.hypot(x1-x2, y1-y2) <= r1 + r2){
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
            }

            if(!this.colision1.isCirculo() && this.colision2.isCirculo() || this.colision1.isCirculo() && !this.colision2.isCirculo()){ // cuadrado - circulo
                int x1_2;
                int y1_2;
                int xC;
                int yC;
                int radio;
                
                if(!this.colision1.isCirculo()){
                    x1_2 = colision1.getX2() + colision1.getPosX();
                    y1_2 = colision1.getY2() + colision1.getPosY();
                    //punto central del circulo
                    xC = colision2.getCentroX() + colision2.getPosX(); 
                    yC = colision2.getCentroY() + colision2.getPosY();
                    radio = colision2.getRadio();
                }
                else{
                    x1 = colision2.getPosX();
                    y1 = colision2.getPosY();

                    x1_2 = colision2.getX2() + colision2.getPosX();
                    y1_2 = colision2.getY2() + colision2.getPosY();
                    //punto central del circulo
                    xC = colision1.getCentroX() + colision1.getPosX(); 
                    yC = colision1.getCentroY() + colision1.getPosY();
                    radio = colision1.getRadio();
                }
                // verificar si hay colision con una esquina del cuadrado
                if(Math.hypot(x1-xC, y1-yC) <= radio){ // esquina superior izquierda
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                else if(Math.hypot(x1_2-xC, y1_2-yC) <= radio){ // esquina inferior derecha
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                else if(Math.hypot(x1_2-xC, y1-yC) <= radio){ // esquina superior derecha
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                else if(Math.hypot(x1-xC, y1_2-yC) <= radio){ // esquina inferior izquierda
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                else{
                    if(xC - radio <= x1_2 && xC - radio >= x1 && yC <= y1_2 && yC >= y1){
                        cont = 1;
                        if(this.activado){
                            this.objeto.Colision(objeto2);
                            this.activado = false;
                        }
                    }
                    if(xC + radio <= x1_2 && xC + radio >= x1 && yC <= y1_2 && yC >= y1){
                        cont = 1;
                        if(this.activado){
                            this.objeto.Colision(objeto2);
                            this.activado = false;
                        }
                    }
                    if(yC - radio <= y1_2 && yC - radio >= y1 && xC < x1_2 && xC >= x1){
                        cont = 1;
                        if(this.activado){
                            this.objeto.Colision(objeto2);
                            this.activado = false;
                        }
                    }
                    if(yC + radio <= y1_2 && yC + radio >= y1 && xC <= x1_2 && xC >= x1){
                        cont = 1;
                        if(this.activado){
                            this.objeto.Colision(objeto2);
                            this.activado = false;
                        }
                    }
                }
            }

            if(!this.colision1.isCirculo() && !this.colision2.isCirculo()){ // cuadrado - cuadrado
                int x1_2 = colision1.getX2() + x1;
                int y1_2 = colision1.getY2() + y1;
                int x2_2 = colision2.getX2() + x2;
                int y2_2 = colision2.getY2() + y2;

                if(x1 <= x2_2 && x1 >= x2 && y1 <= y2_2 && y1 >= y2){
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                if(x1_2 <= x2_2 && x1_2 >= x2 && y1 <= y2_2 && y1 >= y2){
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                if(x1_2 <= x2_2 && x1_2 >= x2 && y1_2 <= y2_2 && y1_2 >= y2){
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
                if(x1 <= x2_2 && x1 >= x2 && y1_2 <= y2_2 && y1_2 >= y2){
                    cont = 1;
                    if(this.activado){
                        this.objeto.Colision(objeto2);
                        this.activado = false;
                    }
                }
            }

            if(cont == 0)
                this.activado = true;
        }
    }

    public ObjectCollision getObjeto() {
        return objeto;
    }

    public ObjectCollision getObjeto2() {
        return objeto2;
    }
}
