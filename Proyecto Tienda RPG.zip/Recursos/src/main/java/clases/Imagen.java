/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import static java.lang.Thread.sleep;
import java.util.ArrayList;
import javax.swing.ImageIcon;

public class Imagen{
    private boolean animacion = false;
    private final ArrayList<ImageIcon> imagenes = new ArrayList();
    private int posicion = 0; // posicion de la imagen a retornar
    private int velocidad = 0; // velocidad de cambio de imagen (0 indica el valor por defecto)
    private final String direccion;

    public Imagen(String direccion) {
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
        this.direccion = direccion;
    }
    
    public Imagen(String direccion, boolean animacion) {
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
        this.animacion = animacion;
        this.direccion = direccion;
    }
    
    public void addImagen(String direccion){
        ImageIcon imagen = new ImageIcon(direccion);
        this.imagenes.add(imagen);
    }

    public String getDireccion() {
        return direccion;
    }
    
    public ImageIcon getImagen() {
        return this.imagenes.get(this.posicion);
    }

    public boolean isAnimacion() {
        return animacion;
    }

    public void setAnimacion(boolean animacion) {
        this.animacion = animacion;
    }

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getPosicion() {
        return posicion;
    }

    public ArrayList<ImageIcon> getImagenes() {
        return imagenes;
    }
    
    public void setImagen(ImageIcon imagen, int pos){
        this.imagenes.remove(pos);
        this.imagenes.add(pos, imagen);
    }
    
    public void cancelarCambio(){
        this.animacion = false;
    }
    
    public void cambiarFrame(){
        int j;
        if(this.velocidad == 0)
            j = 250;
        else
            j = this.velocidad;
        
        if(this.animacion){
            if(this.posicion < this.imagenes.size() - 1)
                this.posicion ++;
            else
                this.posicion = 0;
        }
        for (int i = 0; i < j; i++) {
            if(this.animacion){
                try {
                    sleep(1);
                } catch (Exception e) {}
            }
            else{
                this.animacion = true;
                break;
            }
        }
    }
}
