/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.Item;
import java.awt.MouseInfo;
import javax.swing.JLayeredPane;

/**
 *
 * @author Josué Alvarez M
 */
public class Cursor extends Thread{
    private final Ventana ventana;
    private double x, y = 0;
    private Item item;
    
    public Cursor(Ventana ventana) {
        this.ventana = ventana;
        
        start();
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        if(this.item != null)
                this.ventana.panelPrincipal.remove(this.item.getSprite().getLabel());
        if(item != null){
            this.ventana.panelPrincipal.add(item.getSprite().getLabel(), JLayeredPane.DRAG_LAYER);
        }
        this.item = item;
    }
    
    @Override
    public void run(){
        while(true){
            try {
                int posX = (int) MouseInfo.getPointerInfo().getLocation().getX();
                int posY = (int) MouseInfo.getPointerInfo().getLocation().getY();
                if(posX > ventana.getX() && posX < ventana.getX() + ventana.getWidth()){
                    if(posY > ventana.getY() && posY < ventana.getY() + ventana.getHeight()){
                        x = MouseInfo.getPointerInfo().getLocation().getX() - ventana.getX();
                        y = MouseInfo.getPointerInfo().getLocation().getY() - ventana.getY();
                    }
                }
                
                if(item != null)
                    item.getSprite().setPosicion((int) x - 40, (int) y - 60);
                
                sleep(1);
            } catch (Exception e) {}
        }
    }
    
}
