/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.Item;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Josué Alvarez M
 */
public class Casilla implements ActionListener, MouseListener{
    private final Cursor cursor;
    private Item item;
    private final JLabel cantidad;
    private final JButton botonCasilla;
    public final Imagen imCasilla;
    private boolean enArea = false;
    private boolean activado = false;
    private int tipo = 0; 
    

    public Casilla(String dirImagen, Cursor cursor) {
        this.cursor = cursor;
        this.cantidad = new JLabel("");
        this.botonCasilla = new JButton();
        
        this.cantidad.setFont(new Font("cantidad", 0, 15));
        
        this.imCasilla = new Imagen(dirImagen + "\\gui\\casilla.png");
        
        this.botonCasilla.setIcon(this.imCasilla.getImagen());
        
        iniciarBoton();
    }
    
    public Casilla(String dirImagen, Cursor cursor, int equipo) {
        this.cursor = cursor;
        this.cantidad = new JLabel("");
        this.botonCasilla = new JButton();
        this.tipo = equipo;
        
        this.cantidad.setFont(new Font("cantidad", 0, 15));
        
        if(equipo == 1)
            this.imCasilla = new Imagen(dirImagen + "\\gui\\casillaCasco.png");
        else if(equipo == 2)
            this.imCasilla = new Imagen(dirImagen + "\\gui\\casillaPeto.png");
        else if(equipo == 3)
            this.imCasilla = new Imagen(dirImagen + "\\gui\\casillaPantalon.png");
        else if(equipo == 4)
            this.imCasilla = new Imagen(dirImagen + "\\gui\\casillaBotas.png");
        else
            this.imCasilla = new Imagen(dirImagen + "\\gui\\casillaArma.png");
        
        this.botonCasilla.setIcon(this.imCasilla.getImagen());
        
        iniciarBoton();
    }
    
    
    public void actualizarCantidad(){
        if(item != null){
            botonCasilla.add(cantidad);
            if(item.getCantidad() == 1)
                cantidad.setText("");
            else
                cantidad.setText("x" + String.valueOf(item.getCantidad()));
        }
    }
    
    private void iniciarBoton(){
        botonCasilla.setSize(imCasilla.getImagen().getIconWidth(), imCasilla.getImagen().getIconHeight());
        
        botonCasilla.setLayout(new GridBagLayout());
        botonCasilla.setFocusable(false);
        botonCasilla.setOpaque(false);
        botonCasilla.setContentAreaFilled(false);
        botonCasilla.setBorderPainted(false);
        
        botonCasilla.addActionListener(this);
        botonCasilla.addMouseListener(this);
    }
    
    public Item getItem() {
        return item;
    }

    public Imagen getImCasilla() {
        return imCasilla;
    }
    
    public JButton getBotonCasilla() {
        return botonCasilla;
    }

    public int getTipo() {
        return tipo;
    }
    
    public boolean isActivado() {
        return activado;
    }

    public void setActivado(boolean activado) {
        this.activado = activado;
    }
    
    public void setItem(Item item) {
        this.item = item;
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(cursor.getItem() == null){
            if(item != null){
                cursor.setItem(item);
                item = null;
                botonCasilla.removeAll();

                // de ser un equipo lo desactiva
                if(cursor.getItem().getTipo() > 0 && tipo > 0){
                    Item obj = cursor.getItem();
                    obj.setEquipado(false);
                }
            }
        }
        else if(cursor.getItem().getTipo() == tipo || tipo == 0){
            if(item == null){
                item = cursor.getItem(); // pone el objeto en la casilla
                cursor.setItem(null);
                botonCasilla.add(item.getSprite().getLabel());
                
                // de ser un equipo lo activa
                if(item.getTipo() > 0 && tipo > 0){
                    Item obj = item;
                    obj.setEquipado(true);
                }
            }
            else{
                int cont = 0;
                if(item.getID().equals(cursor.getItem().getID())){
                    cont = 1;
                    // le suma al item la cantidad del item del cursor (de tener espacio)
                    if(item.getCantidad() < item.getCantidadMax()){
                        int cantSobrante = item.agregarCantidad(cursor.getItem().getCantidad());
                        if(cantSobrante == 0)
                            cursor.setItem(null);
                        else
                            cursor.getItem().setCantidad(cantSobrante);
                    }
                    else
                        cont = 0;
                    
                }
                if(cont == 0){
                    Item obj = cursor.getItem();
                    cursor.setItem(item);
                    item = obj;
                    botonCasilla.removeAll();
                    botonCasilla.add(item.getSprite().getLabel());
                    
                    // de ser un equipo lo activa
                    if(item.getTipo() > 0 && tipo > 0){
                        Item equipo = item;
                        equipo.setEquipado(true);
                    }
                    
                    // de ser un equipo lo desactiva
                    if(cursor.getItem().getTipo() > 0 && tipo > 0){
                        Item equipo = item;
                        equipo.setEquipado(false);
                    }
                }
            }
        }
        
        actualizarCantidad();
        botonCasilla.revalidate();
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if(enArea){
            activado = true;
            if(SwingUtilities.isRightMouseButton(e)){
                if(cursor.getItem() == null && item != null){
                    if(item.getCantidad() > 1){
                        int cantidad = item.getCantidad() / 2;
                        
                        item.agregarCantidad(-cantidad);
                        
                        cursor.setItem(item.newInstance());
                        cursor.getItem().setCantidad(cantidad);
                    }
                }
                else if(cursor.getItem() != null){
                    if(cursor.getItem().getTipo() == tipo || tipo == 0){
                        if(item == null){
                            item = cursor.getItem().newInstance();
                            botonCasilla.add(item.getSprite().getLabel());
                            
                            // de ser un equipo lo activa
                            if(item.getTipo() > 0){
                                Item obj = item;
                                obj.setEquipado(true);
                            }
                        }
                        if(cursor.getItem().getCantidad() > 0) {
                            item.agregarCantidad(1);
                            cursor.getItem().agregarCantidad(-1);
                        } 
                        if(cursor.getItem().getCantidad() == 0)
                            cursor.setItem(null);   
                    }  
                }
            }
            actualizarCantidad();
            botonCasilla.revalidate();
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {
        enArea = true;
    }

    @Override
    public void mouseExited(MouseEvent e) {
        enArea = false;
    }
}
