/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.Item;
import java.awt.Font;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.SwingConstants;

/**
 *
 * @author Josué Alvarez M
 */
public class Jugador extends Personaje{
    private final JLabel labelEstadisticas;
    private final Inventario inventario;
    public boolean arriba, abajo, izquierda, derecha;
    private final Imagen quietoD;
    private final Imagen quietoI;
    private final Imagen corriendoD;
    private final Imagen corriendoI;
    private int vista = 1;
    private boolean mostrar = false;
    private final Cursor cursor;
    private int dinero = 1000000;
    private double velExt = 0; // parte decimal de la velocidad, al ser > que 1 la velocidad se incrementa en 1
    
    public Jugador(String dirImagenes, Ventana ventana, Cursor cursor) {
        super("jugador", new Sprite(new Imagen(dirImagenes + "\\jugador\\caballeroQuietoD1.png", true)));
        this.cursor = cursor;
        
        this.inventario = new Inventario(dirImagenes, ventana, cursor, this);
        
        this.labelEstadisticas = new JLabel((new Imagen(dirImagenes + "\\gui\\estadisticas.png")).getImagen());
        this.labelEstadisticas.setHorizontalTextPosition(SwingConstants.CENTER);
        this.labelEstadisticas.setFont(new Font("estadisticas", 0, 25));
        this.labelEstadisticas.setSize(649, 648);
        this.labelEstadisticas.setLocation(625, 125);
        this.labelEstadisticas.setVisible(this.mostrar);
        actualizarEstadisticas();
        ventana.panelPrincipal.add(this.labelEstadisticas, JLayeredPane.POPUP_LAYER);
        
        this.quietoD = sprite.getImagen();
        Colision colision = new Colision(0, 0, quietoD.getImagen().getIconWidth(), quietoD.getImagen().getIconHeight());
        sprite.setColision(colision);
        sprite.getImagen().addImagen(dirImagenes + "\\jugador\\caballeroQuietoD2.png");
        sprite.getImagen().setVelocidad(500);
        
        this.quietoI = new Imagen(dirImagenes + "\\jugador\\caballeroQuietoI1.png", true);
        this.quietoI.addImagen(dirImagenes + "\\jugador\\caballeroQuietoI2.png");
        this.quietoI.setVelocidad(500);
        
        this.corriendoD = new Imagen(dirImagenes + "\\jugador\\caballeroCorriendoD1.png", true);
        this.corriendoD.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoD2.png");
        this.corriendoD.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoD3.png");
        this.corriendoD.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoD4.png");
        this.corriendoD.setVelocidad(50);
        
        this.corriendoI = new Imagen(dirImagenes + "\\jugador\\caballeroCorriendoI1.png", true);
        this.corriendoI.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoI2.png");
        this.corriendoI.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoI3.png");
        this.corriendoI.addImagen(dirImagenes + "\\jugador\\caballeroCorriendoI4.png");
        this.corriendoI.setVelocidad(50);
        
        sprite.addImagen(quietoI);
        sprite.addImagen(corriendoD);
        sprite.addImagen(corriendoI);
    }
    
    public void verificarEstadisticas(){
        ArrayList<Item> equipamento= inventario.getEquipamento();
        
        vidaEq = 0;
        vidaMaxEq = 0;
        ataqueEq = 0;
        defensaMaxEq = 0;
        ataqueMEq = 0;
        defensaMEq = 0;
        velocidadEq = 0;
        
        for (Item equipo : equipamento) {
            if(equipo.isEquipado()){
                vidaMaxEq += equipo.getVidaMax();
                ataqueEq += equipo.getAtaque();
                defensaMaxEq += equipo.getDefensaMax();
                ataqueMEq += equipo.getAtaqueM();
                defensaMEq += equipo.getDefensaM();
                velocidadEq += equipo.getVelocidad();
            }
        }
        
        if(vida > vidaMax + vidaMaxEq)
            vida = vidaMax + vidaMaxEq;
        if(defensa > defensaMax + defensaMaxEq)
            defensa = defensaMax + defensaMaxEq;
    }
    
    public void actualizarEstadisticas(){
        labelEstadisticas.setText("<html><body><p style=\"color:#F2f2f2\";><b>Estadisticas</b> <br><br><br> "
                                    + "Vida Máxima: " + getVidaMax() + "<br><br>Ataque: " + getAtaque() + "<br><br>"
                                    + "Defensa: " + getDefensaMax() + "<br><br>Ataque Mágico: " + getAtaqueM() + "<br><br>"
                                    + "Defensa Mágica: " + getDefensaM() + "<br><br>Velocidad: " + getVelocidad()
                                    + "</p></body></html>");
    }
    
    public void mostrarEstadisticas(){
        if(mostrar){
            labelEstadisticas.setVisible(false);
            mostrar = false;
        }
        else{
            actualizarEstadisticas();
            labelEstadisticas.setVisible(true);
            mostrar = true;
        }
    }
    
    private void moverJugador(){
        try {
            int movX, movY;
            int v = (32 * velocidad) / 100;
            
            velExt += ((32 * (double) velocidad) / 100) - v;
            if(velExt > 1){
                v ++;
                velExt --;
            }
            
            if(this.arriba && !this.abajo)
                movY = -1*v;
            else if(!this.arriba && this.abajo)
                movY = 1*v;
            else
                movY = 0;
            if(this.izquierda && !this.derecha)
                movX = -1*v;
            else if(!this.izquierda && this.derecha)
                movX = v;
            else
                movX = 0;
            
            this.getSprite().setPosicion(this.getSprite().getX() + movX, this.getSprite().getY() + movY);
            sleep(10);
        } catch (Exception e) {}
    }
    
    public Inventario getInventario() {
        return inventario;
    }
    
    public Imagen getQuietoD() {
        return quietoD;
    }

    public Imagen getQuietoI() {
        return quietoI;
    }

    public Imagen getCorriendoD() {
        return corriendoD;
    }

    public Imagen getCorriendoI() {
        return corriendoI;
    }

    public int getVista() {
        return vista;
    }

    public boolean isMostrar() {
        return mostrar;
    }

    public int getDinero() {
        return dinero;
    }

    public JLabel getEstadisticas() {
        return labelEstadisticas;
    }
    
    public void setVista(int vista) {
        this.vista = vista;
    }
    
    public void agregarDinero(int dinero){
        this.dinero += dinero;
        if(this.dinero < 0)
            this.dinero = 0;
    }
    
    @Override
    public void Colision(ObjectCollision item) {
        try{
            Item obj = (Item) item;
            int cantidadSobrante = inventario.addItem(obj);
            if(cantidadSobrante == 0){
                obj.setJugador(this);
                obj.getColision().setActivada(false);
            }
        }
        catch(Exception e){}
    }

    @Override
    public void run() {
        sprite.start();
        boolean quietoDCont = true;
        boolean quietoICont = false;
        boolean corriendoDCont = false;
        boolean corriendoICont = false;
        
        while(true){
            moverJugador();
            verificarEstadisticas();
            
            // Cambiar la animacion dependiendo del movimiento del jugador
            
            if(izquierda && !derecha){
                if(!corriendoICont){
                    sprite.getImagen().cancelarCambio();
                    sprite.cambiarImagen(3);
                    vista = -1;
                    
                    quietoDCont = false;
                    quietoICont = false;
                    corriendoDCont = false;
                    corriendoICont = true;
                }
                continue;
            }
            if(!izquierda && derecha){
                if(!corriendoDCont){
                    sprite.getImagen().cancelarCambio();
                    sprite.cambiarImagen(2);
                    vista = 1;
                    
                    quietoDCont = false;
                    quietoICont = false;
                    corriendoDCont = true;
                    corriendoICont = false;
                }
                continue;
            }
            
            if(arriba && !abajo || !arriba && abajo){
                if(vista == 1){
                    if(!corriendoDCont){
                        sprite.getImagen().cancelarCambio();
                        sprite.cambiarImagen(2);
                        vista = 1;

                        quietoDCont = false;
                        quietoICont = false;
                        corriendoDCont = true;
                        corriendoICont = false;
                    }
                }
                else{
                    if(!corriendoICont){
                        sprite.getImagen().cancelarCambio();
                        sprite.cambiarImagen(3);
                        vista = -1;

                        quietoDCont = false;
                        quietoICont = false;
                        corriendoDCont = false;
                        corriendoICont = true;
                    }
                }
                continue;
            }
            if(cursor.getX() > sprite.getX()){
                if(!quietoDCont){
                    vista = 1;
                    sprite.getImagen().cancelarCambio();
                    sprite.cambiarImagen(0);
                    
                    quietoDCont = true;
                    quietoICont = false;
                    corriendoDCont = false;
                    corriendoICont = false;
                }
                continue;
            }
            else if(!quietoICont){
                    vista = -1;
                    sprite.getImagen().cancelarCambio();
                    sprite.cambiarImagen(1);
                    
                    quietoDCont = false;
                    quietoICont = true;
                    corriendoDCont = false;
                    corriendoICont = false;
            }
        }
    }
    
}
