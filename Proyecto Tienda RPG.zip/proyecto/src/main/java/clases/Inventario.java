/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import clases.objetos.FabricaItems;
import clases.objetos.Item;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;

/**
 *
 * @author Josué Alvarez M
 */
public class Inventario extends Thread implements MouseWheelListener{
    private final Ventana ventana;
    private final Jugador jugador;
    private final ArrayList<Casilla> casillas = new ArrayList();
    private final ArrayList<Item> itemsTirados = new ArrayList();
    private final JLabel labelSeleccion;
    private final JLabel labelInventarioP; //inventario que siempre se muestra
    private final JLabel labelInventario;
    private final JLabel labelEquipo; // label donde se muestra el equipamiento;
    private boolean mostrar = false;
    private final Cursor cursor;
    private int posSeleccion = 0;

    public Inventario(String dirImagenes, Ventana ventana, Cursor cursor, Jugador jugador) {
        this.ventana = ventana;
        this.ventana.panelPrincipal.addMouseWheelListener(this);
        
        this.jugador = jugador;
        
        this.cursor = cursor;
        
        this.labelEquipo = new JLabel((new Imagen(dirImagenes + "\\gui\\equipo.png")).getImagen());
        this.labelEquipo.setSize(1334, 219);
        this.labelEquipo.setLocation(275, 25);
        this.labelEquipo.setVisible(this.mostrar);
        this.ventana.panelPrincipal.add(this.labelEquipo, JLayeredPane.POPUP_LAYER);
        
        this.labelInventarioP = new JLabel((new Imagen(dirImagenes + "\\gui\\inventarioP.png")).getImagen());
        this.labelInventarioP.setSize(1334, 500);
        this.labelInventarioP.setLocation(275, 665);
        this.labelInventarioP.setVisible(true);
        this.ventana.panelPrincipal.add(this.labelInventarioP, JLayeredPane.POPUP_LAYER);
        
        this.labelInventario = new JLabel((new Imagen(dirImagenes + "\\gui\\inventario.png")).getImagen());
        this.labelInventario.setSize(1334, 500);
        this.labelInventario.setLocation(275, 275);
        this.labelInventario.setVisible(this.mostrar);
        this.ventana.panelPrincipal.add(this.labelInventario, JLayeredPane.POPUP_LAYER);
        
        this.labelSeleccion = new JLabel((new Imagen(dirImagenes + "\\gui\\seleccion.png")).getImagen());
        this.labelSeleccion.setSize(120, 120);
        this.labelInventarioP.add(this.labelSeleccion, JLayeredPane.POPUP_LAYER);
        
        iniciarCasillas(dirImagenes);
        
        this.labelSeleccion.setLocation(casillas.get(0).getBotonCasilla().getX(), casillas.get(0).getBotonCasilla().getY());
        
        start();
    }
    
    public void usarItemSeleccionado(){
        Item item = casillas.get(posSeleccion).getItem();
        if(item != null)
            casillas.get(posSeleccion).getItem().usar();
    }
    
    public void tirarItemSeleccionado(){
        Item obj = casillas.get(posSeleccion).getItem();
        if(obj != null){
            //quita el item del inventario
            Item item = FabricaItems.newItem(obj.getID());
            item.setCantidad(-1);
            addItem(item);
            
            item.setCantidad(1);
            
            //define la nueva posicion
            if(jugador.getVista() == 1)
                item.getSprite().setPosicion(jugador.getSprite().getX() + jugador.getSprite().getImageIcon().getIconWidth() + 25, 
                                             jugador.getSprite().getY() + jugador.getSprite().getImageIcon().getIconHeight() / 2);
            else
                item.getSprite().setPosicion(jugador.getSprite().getX() - jugador.getSprite().getImageIcon().getIconWidth() - 25, 
                                             jugador.getSprite().getY() + jugador.getSprite().getImageIcon().getIconHeight() / 2);
            
            for (Item itemTirado : itemsTirados) {
                item.addColision(itemTirado);
            }
            itemsTirados.add(item);
            
            //agrega el item al panelPrincipal
            item.addColision(jugador);
            item.start();
            ventana.panelPrincipal.add(item.getSprite().getLabel());
        }
    }
    
    private void iniciarCasillas(String dirImagenes){
        int tamIm = (new Casilla(dirImagenes, cursor)).getImCasilla().getImagen().getIconWidth();
        int x = 51; 
        int y = 52;
        int ancho = 19 + tamIm;
        int alto = 20 + tamIm;
        
        Casilla c;
        
        for (int i = 0; i < 9; i++) {
            c = new Casilla(dirImagenes, cursor);
            c.getBotonCasilla().setLocation(x + (ancho*i), y + alto);
            this.labelInventarioP.add(c.getBotonCasilla());
            this.casillas.add(c);
        }
        
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 9; j++) {
                c = new Casilla(dirImagenes, cursor);
                c.getBotonCasilla().setLocation(x + (ancho*j), y + (alto*i));
                this.labelInventario.add(c.getBotonCasilla());
                
                this.casillas.add(c);
            }
        }
        
        for (int i = 0; i < 5; i++) {
            c = new Casilla(dirImagenes, cursor, i + 1);
            c.getBotonCasilla().setLocation(x + (ancho*i), y);
            this.labelEquipo.add(c.getBotonCasilla());
            this.casillas.add(c);
        }
    }
    
    public void mostrarInventario(){
        if(mostrar){ // cerrar inventario
            labelInventario.setVisible(false);
            labelEquipo.setVisible(false);
            
            mostrar = false;
        }
        else{ // abrir inventario
            labelInventario.setVisible(true);
            labelEquipo.setVisible(true);
            
            mostrar = true;
        }
    }
    
    private void agregarImagenItem(Casilla casilla, Item item){
        if(casilla.getBotonCasilla().getComponents().length == 0)
            casilla.getBotonCasilla().add(item.getSprite().getLabel());
        else
            this.ventana.panelPrincipal.remove(item.getSprite().getLabel());
        casilla.getBotonCasilla().revalidate();
        casilla.actualizarCantidad();
    }
    
    public int addItem(Item item){
        // se retorna la cantidad de objetos que sobraron (los que no se pudieron agregar)
        while(item.getCantidad() > item.getCantidadMax()){
            item.setCantidad(item.getCantidad() - item.getCantidadMax());
            
            Item item2 = FabricaItems.newItem(item.getID());
            item2.setCantidad(item2.getCantidadMax());
            
            addItem(item2);
        }
        
        
        int cantidadAgregar = item.getCantidad();
        
        for (Casilla c : casillas) {
            if(c.getItem() != null){
                if(c.getItem().getID().equals(item.getID())){
                    cantidadAgregar = c.getItem().agregarCantidad(cantidadAgregar);
                    
                    if(c.getItem().getCantidad() == 0){
                        c.getBotonCasilla().removeAll();
                        c.setItem(null);
                        c.getBotonCasilla().revalidate();
                        break; 
                    }
                    
                    // lo agregó a un objeto existente
                    else if(cantidadAgregar == 0){
                        agregarImagenItem(c, item);
                        break;
                    }
                }
            }
        }
        
        if(cantidadAgregar == 0)
            return 0;
        
        for (Casilla c : casillas) {
            if(c.getItem() == null && c.getTipo() == 0){
                c.setItem(item);
                agregarImagenItem(c, item);
                return 0;
            }
        }
        
        return cantidadAgregar;
    }
    
    public ArrayList<Item> getEquipamento(){
        ArrayList<Item> equipamento = new ArrayList();
        
        for (Casilla c : casillas) {
            if(c.getItem() != null){
                Item equipo = c.getItem();
                if(equipo.getTipo() > 0)
                    equipamento.add(equipo);
            }
        }
        
        return equipamento;
    }

    public boolean isMostrar() {
        return mostrar;
    }

    public ArrayList<Casilla> getCasillas() {
        return casillas;
    }

    public Ventana getVentana() {
        return ventana;
    }
    
    public void setPosSeleccion(int posSeleccion) {
        this.posSeleccion = posSeleccion;
        
        int x = casillas.get(posSeleccion).getBotonCasilla().getX();
        int y = casillas.get(posSeleccion).getBotonCasilla().getY();
        labelSeleccion.setLocation(x, y);
        
        labelInventarioP.revalidate();
    }
    
    @Override
    public void mouseWheelMoved(MouseWheelEvent e) {
        posSeleccion += e.getWheelRotation();
        if(posSeleccion > 8)
            posSeleccion = 8;
        if(posSeleccion < 0)
            posSeleccion = 0;
        
        int x = casillas.get(posSeleccion).getBotonCasilla().getX();
        int y = casillas.get(posSeleccion).getBotonCasilla().getY();
        labelSeleccion.setLocation(x, y);
        
        labelInventarioP.revalidate();
    }
    
    @Override
    public void run(){
        int pos;
        while(true){
            try{
                for (Item itemTirado : itemsTirados) {
                    if(itemTirado.getCantidad() == 0){
                        itemsTirados.remove(itemTirado);
                        break;
                    }
                }


                pos  = 0;
                for (Casilla c : casillas) {
                    if(pos < 9){
                        if(c.isActivado()){
                            c.setActivado(false);
                            setPosSeleccion(pos);
                            break;
                        }
                        pos++;
                    }
                    else
                        break;
                }
            }
            catch(Exception e){}
        }
    }
}
