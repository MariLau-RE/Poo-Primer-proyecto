/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases;

import java.util.ArrayList;

public class Colision{
    private boolean activada = true;
    private boolean circulo = false; //indica si la colision es la de un circulo
    // posicion del centro del Circulo
    private int centroX;
    private int centroY;
    // posicion exacta de  la colision (misma donde se ubica la label)
    private int posX;
    private int posY;
    // limites de la colision del cuadrado
    private int x1;
    private int y1;
    private int x2;
    private int y2;
    // radio del circulo
    private int radio;
    // colisiones con las que interactua 
    private final ArrayList<CollisionController> colisiones = new ArrayList();

    public Colision(int x1, int y1, int x2, int y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }
    
    public Colision newInstance(){
        Colision colision = new Colision(x1, y1, x2, y2);
        colision.setCentro(centroX, centroY);
        if(circulo){
            colision.setCirculo(true);
            colision.setRadio(radio);
        }
        
        return colision;
    }
    
    public Colision(int radio) {
        this.radio = radio;
        this.circulo = true;
    }

    public boolean isActivada() {
        return activada;
    }

    public void setActivada(boolean activada) {
        this.activada = activada;
    }
    
    public boolean isCirculo() {
        return circulo;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }
    
    public void setCirculo(boolean circulo) {
        this.circulo = circulo;
    }

    public void setX1(int x1) {
        this.x1 = x1;
    }

    public void setY1(int y1) {
        this.y1 = y1;
    }

    public void setX2(int x2) {
        this.x2 = x2;
    }

    public void setY2(int y2) {
        this.y2 = y2;
    }
    
    public int getX1() {
        return x1;
    }

    public int getY1() {
        return y1;
    }

    public int getX2() {
        return x2;
    }

    public int getY2() {
        return y2;
    }

    public int getRadio() {
        return radio;
    }

    public int getCentroX() {
        return centroX;
    }

    public int getCentroY() {
        return centroY;
    }

    public int getPosX() {
        return posX;
    }

    public int getPosY() {
        return posY;
    }
    
    public void removeCollisionController(ObjectCollision objeto){
        int pos = 0;
        
        while(true){
            if(colisiones.get(pos).getObjeto().getID().equals(objeto.getID())){
                colisiones.remove(pos);
                break;
            }
            pos ++;
        }
    }
    
    public void setCentro(int x, int y){
        this.centroX = x;
        this.centroY = y;
    }
    
    public void setPosicion(int x, int y){
        this.posX = x;
        this.posY = y;
    }
}
